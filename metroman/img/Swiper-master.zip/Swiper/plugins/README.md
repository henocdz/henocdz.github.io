<h1>Swiper plugins</h1>
<p>Demos and usage <a target="_blank" href="http://www.idangero.us/sliders/swiper/plugins/">here</a></p>

